﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace IngenieSolution
{ 

    public enum Orientations
    {
        North,       //Up
        East,       //Right
        South,      //Down
        West        //Left        
    }

    public struct Coords
    {
        public Coords(int x,int y)
        {
            _x = x;
            _y = y;
        }

        public int _x { get; set; }
        public int _y { get; set; }

    }

    public class RoboticSpiderSimulator

    {
        public RoboticSpiderSimulator(Coords wallSizeCoords,Coords coords, string direction)
        {
            switch (direction)
            {
                case "Left":
                    Orientations = Orientations.West;
                    break;
                case "Right":
                    Orientations = Orientations.East;
                    break;
                default:
                    throw new ArgumentException(string.Format("Invalid Direction: {0}", direction));

            }

            Coords = coords;
            WallSizeCoords = wallSizeCoords;

        }

        public Orientations Orientations
        {
            get; private set;
        }

        public Coords Coords
        {
            get; private set;
        }

        public Coords WallSizeCoords
        {
            get; private set;
        }

        private void SpinRight()
        {
            switch (Orientations)
            {
                case Orientations.North:
                    Orientations = Orientations.East;
                    break;
                case Orientations.East:
                    Orientations = Orientations.South;
                    break;
                case Orientations.South:
                    Orientations = Orientations.West;
                    break;
                case Orientations.West:
                    Orientations = Orientations.North;
                    break;
            }
            
        }

        private void SpinLeft()
        {
            switch (Orientations)
            {
                case Orientations.North:
                    Orientations = Orientations.West;
                    break;
                case Orientations.East:
                    Orientations = Orientations.North;
                    break;
                case Orientations.South:
                    Orientations = Orientations.East;
                    break;
                case Orientations.West:
                    Orientations = Orientations.South;
                    break;
            }
        }

        private void MoveForward()
        {
            switch (Orientations)
            {
                case Orientations.North:
                    Coords = new Coords(Coords._x, Coords._y + 1);
                    break;
                case Orientations.East:
                    Coords = new Coords(Coords._x + 1, Coords._y);
                    break;
                case Orientations.South:
                    Coords = new Coords(Coords._x, Coords._y - 1);
                    break;
                case Orientations.West:
                    Coords = new Coords(Coords._x - 1, Coords._y);
                    break;
            }
        }

        public void ProcessInstructions(string Instructions)
        {
            if(!String.IsNullOrEmpty(Instructions))
            {
                var Movements = new Dictionary<char, Action>
                {
                    ['L'] = SpinLeft,
                    ['R'] = SpinRight,                    
                    ['F'] =  MoveForward,
                };

                Instructions.Where(i => Movements.ContainsKey(i))
                    .Select(i => Movements[i])
                    .ToList()
                    .ForEach(a => a.Invoke());

            }
            else
            {
                Console.WriteLine("Null or Empty Movement Instructiions");
            }
           
        }

        public bool IsRoboticSpiderInsideBoundryWall()
        {
            bool insideWall = false;

            if (this.Coords._x < this.WallSizeCoords._x && this.Coords._y < this.WallSizeCoords._y)
                insideWall = true;

            return insideWall;

        }
        public override string ToString()
        {
            string direction = null;

            switch (this.Orientations)
            {
                case Orientations.East:
                    direction = "Right";
                    break;
                case Orientations.West:
                    direction = "Left";
                    break;                    
            }

            if (IsRoboticSpiderInsideBoundryWall())
            {
                string RoboticSpiderSimulatorPosition = string.Format("{0} {1} {2}", this.Coords._x, this.Coords._y, direction);
                return RoboticSpiderSimulatorPosition;

            }
            else
                return "Invalid Postion - outside given wall";                        
            
        }


        static void Main(string[] args)
        {
            RoboticSpiderSimulator testR = new RoboticSpiderSimulator(new Coords(7,15), new Coords(2, 4),"Left");
            testR.ProcessInstructions("FLFLFRFFLF");

            //Console.WriteLine("New Postion :" + testR.Coords._x + " " + testR.Coords._y + " " + testR.Orientations);
           
            Console.WriteLine(testR.ToString());
        }
    }

}
