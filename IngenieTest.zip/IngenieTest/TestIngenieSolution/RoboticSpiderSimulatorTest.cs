using System;
using IngenieSolution;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestIngenieSolution
{
    [TestClass]
    public class RoboticSpiderSimulatorTest
    {
        [TestMethod]
        public void RobotSpiderCreatedWithValidCoordsAndDirection()
        { 
            var robotSpider = new RoboticSpiderSimulator(new Coords(7, 15), new Coords(2, 4), "Left");
            Assert.AreEqual(Orientations.West, robotSpider.Orientations);
            Assert.AreEqual(2, robotSpider.Coords._x);
            Assert.AreEqual(4, robotSpider.Coords._y);
        }

        [TestMethod]
        public void RobotSpiderCreatedWithInValidDirection()
        {
            Exception exception = null;
            try
            {
                var robotSpider = new RoboticSpiderSimulator(new Coords(7, 15), new Coords(2, 4), "Jeft");
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception);           
        }

        [TestMethod]
        public void TestIsRoboticSpiderInsideBoundryWall()
        {
            var robotSpider = new RoboticSpiderSimulator(new Coords(7, 15), new Coords(9, 4), "Right");

            Assert.IsFalse(robotSpider.IsRoboticSpiderInsideBoundryWall());

        }

        [TestMethod]
        public void TestProcessInstructions()
        {
            var robotSpider = new RoboticSpiderSimulator(new Coords(7, 15), new Coords(2, 4), "Left");
            robotSpider.ProcessInstructions("FLFLFRFFLF");

            Assert.AreEqual(3, robotSpider.Coords._x);
            Assert.AreEqual(1, robotSpider.Coords._y);
            Assert.AreEqual(Orientations.East, robotSpider.Orientations);

        }

        [TestMethod]
        public void TestRoboticSpiderSimulatorToString()
        {
            var robotSpider = new RoboticSpiderSimulator(new Coords(7, 15), new Coords(2, 4), "Left");
            robotSpider.ProcessInstructions("FLFLFRFFLF");

            Assert.AreEqual("3 1 Right", robotSpider.ToString());

        }

    }

   
}
